package com.seohyang.star;



import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class PointController {
	
	@Autowired
	PointDAO dao;
	
	@RequestMapping("pointinsert.do")
	public void insert(PointDTO pointDTO) {
		
		dao.insert(pointDTO);
		System.out.println(pointDTO.id);
		System.out.println(pointDTO.point);
		System.out.println("point insert 요청");
		
	}
	@RequestMapping("pointdelete.do")
	public void delete(PointDTO pointDTO) {
		dao.delete(pointDTO);
		System.out.println("point delete 요청");
	}
	
	@RequestMapping("pointupdate.do")
	public void update(PointDTO pointDTO) {
		dao.update(pointDTO);
		System.out.println("point update 요청");
	}
	@RequestMapping("pointupdate2.do")
	public void update2(PointDTO pointDTO) {
		dao.update(pointDTO);
		System.out.println("point update 요청");
	}
	
	
	  @RequestMapping("pointselect.do") public void select(Model model,PointDTO pointDTO) {
		  pointDTO = dao.select(pointDTO); System.out.println("point select 요청");
	  model.addAttribute("list", pointDTO); 
	  }
	  @RequestMapping("pointselect2.do") public void select2(Model model,PointDTO pointDTO) {
		  pointDTO = dao.select(pointDTO); System.out.println("point select 요청");
		  model.addAttribute("list", pointDTO); 
	  }
	  
	  @RequestMapping("pointSelectAll.do") 
	  public String selectAll(Model model) 
	  { 
		  List<PointDTO>list = dao.selectAll();
	  System.out.println("point selectAll 요청");
	  
	  for(PointDTO dto : list) {
		  
	  System.out.println(dto.id);
	  System.out.println(dto.point);
	  System.out.println(dto.booktitle);
	  System.out.println(dto.bookprice);
	  System.out.println(dto.total);

	  
	  
	  }
	  model.addAttribute("list",list); 
	  return "pointSelectAll";
	
	  
	 
	  }
}
