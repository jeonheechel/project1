package com.seohyang.star;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//@Component 의 자식
//@Service
@Repository		//DB 용 Bean
public class StarDAO {
	
	
	@Autowired
	SqlSessionTemplate myb;
	
	public void insert(StarDTO starDTO) {
		myb.insert("sDAO.insert", starDTO);
		System.out.println("myBatis호출");
	}
	
	public void delete(StarDTO starDTO) {
		myb.delete("sDAO.delete", starDTO);
		
	}
	
	public void update(StarDTO starDTO) {
		myb.update("sDAO.update", starDTO);
	}
	public StarDTO select(StarDTO starDTO) {
		return myb.selectOne("sDAO.select", starDTO);
	}
	
	public List<StarDTO> selectAll() {
		//Mapper 파일에 있는 resultMap 으로 list를 생성해주기 떄문에 List 를 생성해주지 않아도 된다.
		return myb.selectList("sDAO.selectAll");
	}
	
	
}
