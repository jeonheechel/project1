package com.seohyang.star;

public class StarDTO {
	double starnum;

	public double getStarnum() {
		return starnum;
	}

	public void setStarnum(double starnum) {
		this.starnum = starnum;
	}
	
	
	
}
