package com.seohyang.star;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//@Component 의 자식
//@Service
@Repository		//DB 용 Bean
public class PointDAO {
	
	
	@Autowired
	SqlSessionTemplate myb;
	
	public void insert(PointDTO pointDTO) {
		myb.insert("pDAO.insert", pointDTO);
		System.out.println("myBatis호출");
	}
	
	public void delete(PointDTO pointDTO) {
		myb.delete("pDAO.delete", pointDTO);
		
	}
	
	public void update(PointDTO pointDTO) {
		myb.update("pDAO.update", pointDTO);
	}
	public PointDTO select(PointDTO pointDTO) {
		return myb.selectOne("pDAO.select", pointDTO);
	}
	
	public List<PointDTO> selectAll() {
		//Mapper 파일에 있는 resultMap 으로 list를 생성해주기 떄문에 List 를 생성해주지 않아도 된다.
		return myb.selectList("pDAO.selectAll");
	}
	
	
}
