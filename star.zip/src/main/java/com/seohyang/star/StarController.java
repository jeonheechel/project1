package com.seohyang.star;



import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class StarController {
	
	@Autowired
	StarDAO dao;
	
	@RequestMapping("insert.do")
	public void insert(StarDTO starDTO) {
		
		dao.insert(starDTO);
		System.out.println(starDTO.starnum);
		System.out.println("star insert 요청");
		
	}
	@RequestMapping("delete.do")
	public void delete(StarDTO starDTO) {
		dao.delete(starDTO);
		System.out.println("star delete 요청");
	}
	
	@RequestMapping("update.do")
	public void update(StarDTO starDTO) {
		dao.update(starDTO);
		System.out.println("star update 요청");
	}
	
	
	  @RequestMapping("select.do") public String select(Model model,StarDTO starDTO) {
		  starDTO = dao.select(starDTO); System.out.println("star select 요청");
	  model.addAttribute("list", starDTO); 
	  return "select";
	  }
	  
	  @RequestMapping("selectAll.do") 
	  public String selectAll(Model model) 
	  { List<StarDTO>list = dao.selectAll();
	  System.out.println("star selectAll 요청");
	  
	  for(StarDTO dto : list) {
		  
	  System.out.println(dto.starnum);
	  
	  
	  model.addAttribute("list",list); 
	  return "selectAll";
	  }
	return null;
	  
	 
	  }
}
