package com.seohyang.book;

public class UsedDTO {
	int booknum;
	
	String booktitle;
	String bookcontent;
	String bookgenre;
	String bookauthor;
	String bookprice;
	String bookuser;
	String booktel;
	String bookaddr;
	

	

	
	public int getBooknum() {
		return booknum;
	}
	public void setBooknum(int booknum) {
		this.booknum = booknum;
	}
	public String getBooktitle() {
		return booktitle;
	}
	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}
	public String getBookcontent() {
		return bookcontent;
	}
	public void setBookcontent(String bookcontent) {
		this.bookcontent = bookcontent;
	}
	public String getBookgenre() {
		return bookgenre;
	}
	public void setBookgenre(String bookgenre) {
		this.bookgenre = bookgenre;
	}
	public String getBookauthor() {
		return bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}
	public String getBookprice() {
		return bookprice;
	}
	public void setBookprice(String bookprice) {
		this.bookprice = bookprice;
	}
	public String getBookuser() {
		return bookuser;
	}
	public void setBookuser(String bookuser) {
		this.bookuser = bookuser;
	}
	public String getBooktel() {
		return booktel;
	}
	public void setBooktel(String booktel) {
		this.booktel = booktel;
	}
	public String getBookaddr() {
		return bookaddr;
	}
	public void setBookaddr(String bookaddr) {
		this.bookaddr = bookaddr;
	}
	
	
	
}
